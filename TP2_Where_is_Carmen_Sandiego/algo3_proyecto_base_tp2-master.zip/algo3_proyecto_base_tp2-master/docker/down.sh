# /bin/bash
set -e

docker-compose -f docker/docker-compose.yaml down
